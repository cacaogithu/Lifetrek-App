-- Date: 2026-01-26
-- Purpose: Prevent runaway API costs by tracking spending and enforcing limits

-- 1. API Cost Tracking Table
CREATE TABLE IF NOT EXISTS public.api_cost_tracking (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    operation TEXT NOT NULL, -- 'carousel_generation', 'image_generation', 'chat', etc.
    service TEXT NOT NULL, -- 'openrouter', 'vertexai', 'stable-diffusion', etc.
    model TEXT, -- 'gemini-2.0-flash', 'imagen-3', etc.
    estimated_cost DECIMAL(10, 4) NOT NULL, -- in USD
    actual_cost DECIMAL(10, 4), -- if available from provider
    request_count INTEGER DEFAULT 1,
    metadata JSONB, -- additional details
    created_at TIMESTAMPTZ DEFAULT NOW(),
    date DATE DEFAULT CURRENT_DATE
);

-- Indexes for fast queries
CREATE INDEX idx_api_cost_tracking_user_id ON public.api_cost_tracking(user_id);
CREATE INDEX idx_api_cost_tracking_date ON public.api_cost_tracking(date DESC);
CREATE INDEX idx_api_cost_tracking_operation ON public.api_cost_tracking(operation);
CREATE INDEX idx_api_cost_tracking_service ON public.api_cost_tracking(service);
CREATE INDEX idx_api_cost_tracking_created_at ON public.api_cost_tracking(created_at DESC);

-- 2. Daily Spending Summary (Materialized View for Performance)
CREATE MATERIALIZED VIEW IF NOT EXISTS public.daily_spending_summary AS
SELECT 
    date,
    user_id,
    operation,
    service,
    SUM(estimated_cost) as total_cost,
    SUM(request_count) as total_requests,
    COUNT(*) as operation_count
FROM public.api_cost_tracking
GROUP BY date, user_id, operation, service;

CREATE UNIQUE INDEX idx_daily_spending_summary_unique 
    ON public.daily_spending_summary(date, user_id, operation, service);

-- Refresh function for materialized view
CREATE OR REPLACE FUNCTION refresh_daily_spending_summary()
RETURNS void AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY public.daily_spending_summary;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
