# Double Login Issue Analysis - Lifetrek App Orchestrator

## Problem Summary

The Lifetrek app's Content Orchestrator is experiencing a **double login issue** where authentication is being checked redundantly, causing users to authenticate multiple times.

## Root Cause

The issue stems from **redundant authentication checks** at multiple levels:

### 1. ContentOrchestrator Component (Primary Issue)
**File:** `/src/pages/Admin/ContentOrchestrator.tsx` (Lines 30-35)

```typescript
useEffect(() => {
    if (!isAuthLoading && !isAdmin) {
        toast.error("Acesso negado.");
        navigate("/admin/login");
    }
}, [isAuthLoading, isAdmin, navigate]);
```

This component uses the `useAdminPermissions` hook which:
- Calls `supabase.auth.getUser()` to get the current user
- Queries the `admin_permissions` table
- Falls back to checking `admin_users` table (legacy support)

### 2. useAdminPermissions Hook
**File:** `/src/hooks/useAdminPermissions.ts` (Lines 22-65)

```typescript
const checkPermissions = async () => {
    try {
        const { data: { user } } = await supabase.auth.getUser();

        if (!user?.email) {
            setPermissionLevel("none");
            setIsLoading(false);
            return;
        }

        setUserEmail(user.email);

        // Query admin_permissions table
        const { data, error } = await supabase
            .from("admin_permissions")
            .select("*")
            .eq("email", user.email)
            .single();

        if (error || !data) {
            // Fallback: check if they're in admin_users (legacy support)
            const { data: adminData } = await supabase
                .from("admin_users")
                .select("*")
                .eq("user_id", user.id)
                .single();

            if (adminData) {
                setPermissionLevel("admin");
            } else {
                setPermissionLevel("none");
            }
        } else {
            setPermissionLevel(data.permission_level as PermissionLevel);
            setDisplayName(data.display_name);
        }
    } catch (error) {
        console.error("Error checking permissions:", error);
        setPermissionLevel("none");
    } finally {
        setIsLoading(false);
    }
};
```

### 3. AdminLogin Component (Secondary Issue)
**File:** `/src/pages/AdminLogin.tsx` (Lines 31-42)

```typescript
if (data.user) {
    // Check if user is admin - try both tables
    const [adminUsersCheck, adminPermissionsCheck] = await Promise.all([
      supabase.from("admin_users").select("*").eq("user_id", data.user.id).single(),
      supabase.from("admin_permissions").select("*").eq("email", data.user.email).single()
    ]);

    const isAdmin = adminUsersCheck.data || adminPermissionsCheck.data;

    if (!isAdmin) {
      await supabase.auth.signOut();
      toast.error("Access denied. Not an admin user.");
      return;
    }

    toast.success("Login successful!");
    navigate("/admin");
}
```

## Why This Causes Double Login

1. **User logs in** via `AdminLogin.tsx`
2. Login component checks both `admin_users` and `admin_permissions` tables
3. User is redirected to `/admin` or `/admin/orchestrator`
4. **ContentOrchestrator mounts** and immediately runs `useAdminPermissions` hook
5. Hook calls `supabase.auth.getUser()` again
6. Hook queries `admin_permissions` table again
7. Hook falls back to `admin_users` table again
8. If any check fails or times out, user is redirected back to login

## Additional Issues Identified

### Session Expiry Handling
The ContentOrchestrator has multiple places where it redirects to login on auth errors:
- Lines 70-72: On 401 from functions.invoke
- Lines 98-102: On general auth errors

This can cause unexpected logouts even when the session is valid.

### Race Conditions
The `useEffect` in ContentOrchestrator (lines 30-35) runs immediately on mount, which can race with:
- The Supabase auth state initialization
- The `useAdminPermissions` hook's initial check
- Any ongoing session refresh

## Impact

- **Poor User Experience**: Users may need to log in multiple times
- **Unnecessary API Calls**: Multiple redundant database queries on every page load
- **Session Management Issues**: Premature logouts due to race conditions
- **Performance**: Slower page loads due to redundant authentication checks

## Recommended Solution

See `double_login_fix.md` for the complete fix implementation.
