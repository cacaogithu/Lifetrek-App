# Double Login Issue - Complete Fix Guide

## Overview

This document provides a complete solution to the double login issue in the Lifetrek app's Content Orchestrator component.

## Changes Required

### 1. Update ContentOrchestrator.tsx ✅

**File:** `/src/pages/Admin/ContentOrchestrator.tsx`

**Changes Made:**

#### A. Simplified Authentication Check (Lines 30-40)
**Before:**
```typescript
useEffect(() => {
    if (!isAuthLoading && !isAdmin) {
        toast.error("Acesso negado.");
        navigate("/admin/login");
    }
}, [isAuthLoading, isAdmin, navigate]);
```

**After:**
```typescript
// Only redirect if explicitly not an admin after loading completes
useEffect(() => {
    if (!isAuthLoading && isAdmin === false) {
        toast.error("Acesso negado.");
        navigate("/admin/login");
    }
}, [isAuthLoading, isAdmin, navigate]);
```

**Why:** The explicit `=== false` check prevents redirecting during the initial undefined state, reducing race conditions.

#### B. Improved Error Handling (Lines 67-91)
**Before:**
```typescript
if (error) {
    if (error instanceof FunctionsHttpError && error.context?.status === 401) {
        toast.error("Sessão expirada. Por favor, faça login novamente.");
        navigate("/admin/login");
        return;
    }

    if (error.status === 429) {
        toast.error("Limite de solicitações atingido. Aguarde 1 minuto.");
        return;
    }

    throw error;
}
```

**After:**
```typescript
if (error) {
    // Only redirect on true auth failures, not on API errors
    if (error instanceof FunctionsHttpError) {
        if (error.context?.status === 401) {
            toast.error("Sessão expirada. Por favor, faça login novamente.");
            await supabase.auth.signOut();
            navigate("/admin/login");
            return;
        }
        
        if (error.status === 429) {
            toast.error("Limite de solicitações atingido. Aguarde 1 minuto.");
            return;
        }
    }

    throw error;
}
```

**Why:** 
- Added explicit `signOut()` call before redirect to clean up session
- Better error type checking to avoid false positives

#### C. More Precise Auth Error Detection (Lines 94-120)
**Before:**
```typescript
const isAuthError = error.status === 401 && !error.message?.toLowerCase().includes("openrouter");

if (isAuthError) {
    toast.error("Sessão expirada. Redirecionando...");
    navigate("/admin/login");
}
```

**After:**
```typescript
// Only redirect on Supabase Auth errors, not on API/network errors
const isSupabaseAuthError = 
    error instanceof FunctionsHttpError && 
    error.context?.status === 401;

if (isSupabaseAuthError) {
    toast.error("Sessão expirada. Redirecionando...");
    await supabase.auth.signOut();
    navigate("/admin/login");
}
```

**Why:** 
- More precise error type checking
- Prevents false redirects on non-auth errors
- Ensures proper session cleanup

### 2. Optional: Add Route Protection (Recommended)

**File:** `/src/App.tsx`

Add a protected route wrapper to handle authentication at the router level:

```typescript
import { Navigate } from "react-router-dom";
import { useAdminPermissions } from "@/hooks/useAdminPermissions";
import { LoadingSpinner } from "@/components/LoadingSpinner";

function ProtectedAdminRoute({ children }: { children: React.ReactNode }) {
    const { isAdmin, isLoading } = useAdminPermissions();

    if (isLoading) {
        return <LoadingSpinner />;
    }

    if (!isAdmin) {
        return <Navigate to="/admin/login" replace />;
    }

    return <>{children}</>;
}

// Then wrap admin routes:
<Route path="/admin" element={
    <ProtectedAdminRoute>
        <Suspense fallback={<LoadingSpinner />}>
            <AdminLayout>
                <Outlet />
            </AdminLayout>
        </Suspense>
    </ProtectedAdminRoute>
}>
    <Route index element={<DashboardOverview />} />
    <Route path="orchestrator" element={<ContentOrchestrator />} />
    {/* other admin routes */}
</Route>
```

**Why:** This centralizes authentication logic and prevents redundant checks in individual components.

### 3. Optional: Optimize useAdminPermissions Hook

**File:** `/src/hooks/useAdminPermissions.ts`

Consider adding memoization to prevent unnecessary re-checks:

```typescript
import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export function useAdminPermissions() {
    const [permissionLevel, setPermissionLevel] = useState<PermissionLevel>("none");
    const [displayName, setDisplayName] = useState<string | null>(null);
    const [userEmail, setUserEmail] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    const checkPermissions = useCallback(async () => {
        try {
            const { data: { user } } = await supabase.auth.getUser();

            if (!user?.email) {
                setPermissionLevel("none");
                setIsLoading(false);
                return;
            }

            setUserEmail(user.email);

            // Query admin_permissions table
            const { data, error } = await supabase
                .from("admin_permissions")
                .select("*")
                .eq("email", user.email)
                .single();

            if (error || !data) {
                // Fallback: check if they're in admin_users (legacy support)
                const { data: adminData } = await supabase
                    .from("admin_users")
                    .select("*")
                    .eq("user_id", user.id)
                    .single();

                if (adminData) {
                    setPermissionLevel("admin");
                } else {
                    setPermissionLevel("none");
                }
            } else {
                setPermissionLevel(data.permission_level as PermissionLevel);
                setDisplayName(data.display_name);
            }
        } catch (error) {
            console.error("Error checking permissions:", error);
            setPermissionLevel("none");
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        checkPermissions();

        // Listen for auth state changes
        const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
            if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
                checkPermissions();
            } else if (event === 'SIGNED_OUT') {
                setPermissionLevel("none");
                setDisplayName(null);
                setUserEmail(null);
            }
        });

        return () => {
            subscription.unsubscribe();
        };
    }, [checkPermissions]);

    // ... rest of the hook
}
```

**Why:** 
- Listens to auth state changes for automatic updates
- Prevents unnecessary re-checks
- Better handles session refresh scenarios

## Implementation Steps

1. **Backup the current file:**
   ```bash
   cp src/pages/Admin/ContentOrchestrator.tsx src/pages/Admin/ContentOrchestrator.tsx.backup
   ```

2. **Apply the fix:**
   ```bash
   cp ContentOrchestrator.fixed.tsx src/pages/Admin/ContentOrchestrator.tsx
   ```

3. **Test the changes:**
   - Clear browser cache and cookies
   - Log in to the admin panel
   - Navigate to the Content Orchestrator
   - Verify you're not prompted to log in again
   - Test session expiry handling
   - Test error scenarios (network errors, API errors)

4. **Monitor for issues:**
   - Check browser console for errors
   - Verify authentication flow in Network tab
   - Test with different user permission levels

## Expected Behavior After Fix

✅ **Single Login:** Users log in once and stay authenticated  
✅ **No Redundant Checks:** Authentication is verified only when necessary  
✅ **Proper Session Handling:** Session expiry triggers clean logout and redirect  
✅ **Better Error Handling:** API errors don't cause false authentication failures  
✅ **Improved Performance:** Fewer database queries on page load  

## Testing Checklist

- [ ] User can log in successfully
- [ ] User is not prompted to log in again when accessing orchestrator
- [ ] Session expiry properly redirects to login
- [ ] Network errors don't cause false logouts
- [ ] API errors are handled gracefully
- [ ] Permission checks work correctly
- [ ] Page loads faster (fewer DB queries)

## Rollback Plan

If issues occur, restore the backup:
```bash
cp src/pages/Admin/ContentOrchestrator.tsx.backup src/pages/Admin/ContentOrchestrator.tsx
```

## Additional Recommendations

1. **Consolidate Authentication Logic:** Consider creating a centralized auth context/provider
2. **Add Session Monitoring:** Implement session timeout warnings
3. **Improve Error Messages:** Provide more specific error messages for different failure scenarios
4. **Add Logging:** Implement proper logging for authentication events
5. **Database Optimization:** Consider consolidating `admin_users` and `admin_permissions` tables

## Files Included

- `ContentOrchestrator.fixed.tsx` - Fixed version of the component
- `double_login_analysis.md` - Detailed analysis of the issue
- `double_login_fix.md` - This implementation guide

## Support

If you encounter any issues after applying this fix, check:
1. Browser console for JavaScript errors
2. Network tab for failed API calls
3. Supabase logs for authentication errors
4. Database tables for permission data consistency
