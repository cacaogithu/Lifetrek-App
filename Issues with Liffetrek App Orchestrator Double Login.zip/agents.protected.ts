// Protected version of agents.ts with cost tracking
// This file shows how to integrate cost protection into the carousel generation pipeline

import { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";
import {
  CarouselParams,
  CarouselStrategy,
  CarouselCopy,
  GeneratedImage,
  QualityReview
} from "./types.ts";
import {
  getBrandGuidelines,
  validateCarouselStructure,
  extractJSON,
  searchCompanyAssets,
  generateCarouselEmbedding,
  searchSimilarCarousels,
  deepResearch
} from "./agent_tools.ts";
import {
  withCostTracking,
  checkSpendingLimit,
  logAPICost,
  getModelCost,
  createCostAlert
} from "./costTracking.ts";

const OPENROUTER_API_KEY = Deno.env.get("OPENROUTER_API_KEY");
const TEXT_MODEL = "google/gemini-2.0-flash-001";
const IMAGE_MODEL = "stabilityai/stable-diffusion-xl-base-1.0";

// COST PROTECTION: Maximum images per carousel
const MAX_IMAGES_PER_CAROUSEL = 7;
const MAX_CAROUSELS_PER_USER_PER_DAY = 10;

async function callOpenRouter(
  messages: { role: string; content: string }[],
  temperature: number = 0.7
): Promise<string> {
  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
      "HTTP-Referer": "https://lifetrek.app",
      "X-Title": "Lifetrek App",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: TEXT_MODEL,
      messages: messages,
      temperature: temperature,
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`OpenRouter Error: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}

async function callOpenRouterImage(prompt: string): Promise<string | null> {
  try {
    const response = await fetch("https://openrouter.ai/api/v1/images/generations", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
        "HTTP-Referer": "https://lifetrek.app",
        "X-Title": "Lifetrek App",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: IMAGE_MODEL,
        prompt: prompt,
        n: 1,
        size: "1024x1024"
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.warn(`OpenRouter Image Error: ${response.status} - ${errorText}`);
      return null;
    }

    const data = await response.json();
    return data.data?.[0]?.url || null;
  } catch (error) {
    console.warn("OpenRouter Image Call Failed:", error);
    return null;
  }
}

/**
 * PROTECTED: Check if user has exceeded daily carousel limit
 */
async function checkCarouselLimit(
  supabase: SupabaseClient,
  userId: string | null
): Promise<{ allowed: boolean; count: number; limit: number }> {
  if (!userId) {
    return { allowed: true, count: 0, limit: MAX_CAROUSELS_PER_USER_PER_DAY };
  }

  const today = new Date().toISOString().split('T')[0];
  
  const { count, error } = await supabase
    .from('api_cost_tracking')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('operation', 'carousel_generation')
    .eq('date', today);

  if (error) {
    console.error("Error checking carousel limit:", error);
    return { allowed: true, count: 0, limit: MAX_CAROUSELS_PER_USER_PER_DAY };
  }

  const allowed = (count || 0) < MAX_CAROUSELS_PER_USER_PER_DAY;
  
  if (!allowed) {
    await createCostAlert(
      supabase,
      "limit_exceeded",
      "warning",
      userId,
      "carousel_generation",
      count || 0,
      MAX_CAROUSELS_PER_USER_PER_DAY,
      `User has reached daily carousel generation limit (${count}/${MAX_CAROUSELS_PER_USER_PER_DAY})`
    );
  }

  return { 
    allowed, 
    count: count || 0, 
    limit: MAX_CAROUSELS_PER_USER_PER_DAY 
  };
}

/**
 * Agent 1: Strategist (PROTECTED)
 */
export async function strategistAgent(
  params: CarouselParams,
  supabase: SupabaseClient,
  userId: string | null
): Promise<CarouselStrategy> {
  const startTime = Date.now();
  console.log("🎯 Strategist Agent: Planning carousel strategy...");

  // COST PROTECTION: Check carousel limit first
  const limitCheck = await checkCarouselLimit(supabase, userId);
  if (!limitCheck.allowed) {
    throw new Error(
      `Daily carousel limit reached (${limitCheck.count}/${limitCheck.limit}). Please try again tomorrow.`
    );
  }

  // COST PROTECTION: Wrap in cost tracking
  return await withCostTracking(
    supabase,
    userId,
    "carousel_generation",
    "openrouter",
    TEXT_MODEL,
    async () => {
      const brand = getBrandGuidelines(params.profileType);

      // Similar carousels search
      let similarCarouselsContext = "";
      try {
        const queryEmbedding = await generateCarouselEmbedding(
          params.topic,
          [{ headline: params.topic, body: params.painPoint || "" }]
        );

        if (queryEmbedding) {
          const similarCarousels = await searchSimilarCarousels(supabase, queryEmbedding, 0.70, 3);

          if (similarCarousels && similarCarousels.length > 0) {
            similarCarouselsContext = `\n\n**Similar Successful Carousels** (for inspiration only):
${similarCarousels.map((c: any, i: number) => `${i + 1}. "${c.topic}" (Quality: ${c.quality_score}/100)`).join('\n')}`;
          }
        }
      } catch (error) {
        console.warn("⚠️ Could not search similar carousels:", error);
      }

      // Research (only if enabled)
      const researchLevel = params.researchLevel || 'light';
      let researchContext = "";

      if (researchLevel !== 'none') {
        try {
          const researchQuery = `${params.topic} trends for ${params.targetAudience}`;
          const maxResearchTime = researchLevel === 'deep' ? 15000 : 10000;
          const researchResults = await deepResearch(researchQuery, maxResearchTime);

          if (researchResults) {
            researchContext = `\n\n**Industry Research**:\n${researchResults}`;
          }
        } catch (error) {
          console.warn("⚠️ Could not complete research:", error);
        }
      }

      const systemPrompt = `You are a LinkedIn carousel strategy expert for ${brand.companyName}.
${similarCarouselsContext}${researchContext}

**Task**: Create a strategic plan for a LinkedIn carousel about "${params.topic}".
**Target Audience**: ${params.targetAudience}
**Requirements**:
- Plan 5-7 slides total (including hook and CTA)
- Create a compelling narrative arc
- Follow proven structure: Hook → Value → Value → Value → CTA
- Output ONLY valid JSON.`;

      const response = await callOpenRouter([
        { role: "system", content: systemPrompt },
        { role: "user", content: `Create strategy for topic: ${params.topic}` }
      ]);

      const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '');
      const strategy = extractJSON(cleanResponse);

      console.log(`✅ Strategist: Planned ${strategy.slide_count}-slide carousel in ${Date.now() - startTime}ms`);
      return strategy;
    }
  );
}

/**
 * Agent 2: Copywriter (PROTECTED)
 */
export async function copywriterAgent(
  params: CarouselParams,
  strategy: CarouselStrategy,
  supabase: SupabaseClient,
  userId: string | null
): Promise<CarouselCopy> {
  const startTime = Date.now();
  console.log("✍️ Copywriter Agent: Writing carousel copy...");

  return await withCostTracking(
    supabase,
    userId,
    "carousel_generation",
    "openrouter",
    TEXT_MODEL,
    async () => {
      const brand = getBrandGuidelines(params.profileType);

      const prompt = `You are an expert LinkedIn copywriter for ${brand.companyName}.

**Task**: Write compelling copy for a ${strategy.slide_count}-slide LinkedIn carousel.
**Topic**: ${params.topic}
**Target Audience**: ${params.targetAudience}
**Narrative Arc**: ${strategy.narrative_arc}
**Key Messages**: ${strategy.key_messages.join(', ')}
**Brand Tone**: ${brand.tone}

**Slide Structure**:
1. Hook Slide (type: "hook"): Attention-grabbing opening
2-${strategy.slide_count - 1}. Content Slides (type: "content"): Value delivery
${strategy.slide_count}. CTA Slide (type: "cta"): Clear call to action

**Output Format** (JSON only):
{
  "topic": "${params.topic}",
  "caption": "LinkedIn post caption with hashtags",
  "slides": [
    { "type": "hook", "headline": "...", "body": "..." },
    { "type": "content", "headline": "...", "body": "..." },
    { "type": "cta", "headline": "...", "body": "..." }
  ]
}`;

      const response = await callOpenRouter([{ role: "user", content: prompt }]);
      const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '');
      const copy: CarouselCopy = extractJSON(cleanResponse);

      console.log(`✅ Copywriter: Created ${copy.slides.length} slides in ${Date.now() - startTime}ms`);
      return copy;
    }
  );
}

/**
 * Agent 3: Designer (PROTECTED)
 */
export async function designerAgent(
  supabase: SupabaseClient,
  userId: string | null,
  params: CarouselParams,
  copy: CarouselCopy
): Promise<GeneratedImage[]> {
  const startTime = Date.now();
  console.log("🎨 Designer Agent: Creating visual assets...");

  const images: GeneratedImage[] = [];
  
  // COST PROTECTION: Limit number of images
  const slideCount = Math.min(copy.slides.length, MAX_IMAGES_PER_CAROUSEL);
  
  if (copy.slides.length > MAX_IMAGES_PER_CAROUSEL) {
    console.warn(`⚠️ Limiting images to ${MAX_IMAGES_PER_CAROUSEL} (requested ${copy.slides.length})`);
  }

  for (let i = 0; i < slideCount; i++) {
    const slide = copy.slides[i];

    // 1. Try to find real assets first (free)
    try {
      const assetQuery = slide.headline.split(' ').slice(0, 3).join(' ');
      const realAsset = await searchCompanyAssets(supabase, assetQuery);

      if (realAsset) {
        images.push({
          slide_index: i,
          image_url: realAsset.url,
          asset_source: 'real',
          asset_url: realAsset.url
        });
        console.log(`✅ Designer: Using real asset for slide ${i + 1} (no cost)`);
        continue;
      }
    } catch (e) {
      console.warn("Asset search failed", e);
    }

    // 2. Generate AI Image (expensive - track cost)
    const imagePrompt = `Professional medical device manufacturing. ${slide.headline}. High quality, photorealistic.`;

    console.log(`🎨 Designer: Generating AI image for slide ${i + 1}...`);
    
    // COST PROTECTION: Check limit before each image
    const costCheck = await checkSpendingLimit(
      supabase,
      userId,
      "image_generation",
      getModelCost(IMAGE_MODEL)
    );

    if (!costCheck.allowed) {
      console.warn(`⚠️ Spending limit reached, using placeholder for slide ${i + 1}`);
      images.push({
        slide_index: i,
        image_url: "https://placehold.co/1080x1080/004F8F/FFFFFF?text=Spending+Limit+Reached",
        asset_source: 'placeholder'
      });
      continue;
    }

    // Log cost before generation
    await logAPICost(supabase, {
      userId,
      operation: "image_generation",
      service: "openrouter",
      model: IMAGE_MODEL,
      estimatedCost: getModelCost(IMAGE_MODEL),
      metadata: { slide_index: i, prompt: imagePrompt }
    });

    const imageUrl = await callOpenRouterImage(imagePrompt);

    if (imageUrl) {
      images.push({
        slide_index: i,
        image_url: imageUrl,
        asset_source: 'ai-generated'
      });
      console.log(`✅ Designer: Generated AI image for slide ${i + 1}`);
    } else {
      console.warn(`⚠️ Designer: Failed to generate image for slide ${i + 1}`);
      images.push({
        slide_index: i,
        image_url: "https://placehold.co/1080x1080/004F8F/FFFFFF?text=Generation+Failed",
        asset_source: 'placeholder'
      });
    }
  }

  console.log(`✅ Designer: Created ${images.length} images in ${Date.now() - startTime}ms`);
  return images;
}

/**
 * Agent 4: Brand Analyst (PROTECTED)
 */
export async function brandAnalystAgent(
  copy: CarouselCopy,
  images: GeneratedImage[],
  supabase: SupabaseClient,
  userId: string | null
): Promise<QualityReview> {
  const startTime = Date.now();
  console.log("🔍 Brand Analyst: Reviewing carousel quality...");

  return await withCostTracking(
    supabase,
    userId,
    "carousel_generation",
    "openrouter",
    TEXT_MODEL,
    async () => {
      const brand = getBrandGuidelines();

      const prompt = `You are a strict brand quality analyst for ${brand.companyName}.

**Task**: Review this LinkedIn carousel.
**Content**: ${copy.topic} / ${copy.caption}
**Slides**: ${copy.slides.map(s => `[${s.type}] ${s.headline}`).join(', ')}

**Criteria**: Clarity, Value, Engagement, Brand Alignment

**Output JSON**:
{
  "overall_score": 85,
  "feedback": "Assessment...",
  "needs_regeneration": false,
  "issues": [],
  "strengths": []
}`;

      const response = await callOpenRouter([{ role: "user", content: prompt }]);
      const cleanResponse = response.replace(/```json/g, '').replace(/```/g, '');
      const review: QualityReview = extractJSON(cleanResponse);

      if (typeof review.overall_score !== 'number') review.overall_score = 75;
      review.needs_regeneration = review.overall_score < 70;

      console.log(`✅ Brand Analyst: Score ${review.overall_score}/100 in ${Date.now() - startTime}ms`);
      return review;
    }
  );
}
